"use strict";
var gulp = require("gulp");
var sass = require("gulp-sass")(require("sass"));
var compass = require("gulp-compass");
var sourcemaps = require("gulp-sourcemaps");
var uglify = require("gulp-uglify");
var pump = require("pump");
var autoprefixer = require("autoprefixer");
var postcss = require("gulp-postcss");
var cssnano = require("gulp-cssnano");
var path = require("path");

var sassOptions = {
    errLogToConsole: true,
    outputStyle: "compressed",
};

var plugins = [autoprefixer()];

function styles() {
    return (
        gulp
            .src(["scss/**/*.scss"])
            // .pipe(sourcemaps.init())
            .pipe(sass(sassOptions).on("error", sass.logError))
            .pipe(postcss(plugins))
            // .pipe(sourcemaps.write('.'))
            .pipe(gulp.dest("css/"))
    );
}

function watch() {
    return gulp.watch("scss/**/*.scss", gulp.parallel(styles));
}

gulp.task("default", watch);
