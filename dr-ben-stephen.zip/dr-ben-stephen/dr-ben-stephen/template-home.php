<?php
/*
Template Name: Home
*/ 
?>
<?php get_header(); ?>
<section class="banner-section">
    <div class="container-fluid">
        <div class="row">
            <?php if( have_rows('banner_contents') ): ?>
                <?php while( have_rows('banner_contents') ): the_row(); ?>
                    <div id="carouselExampleFade" class="carousel slide carousel-fade" data-bs-ride="carousel">
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                            <?php 
$image = get_sub_field('banner_image');
if( !empty( $image ) ): ?>
    <img class="d-block w-100" src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>" />
<?php endif; ?>
                            </div>
                        </div>
                        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Previous</span>
                        </button>
                        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Next</span>
                        </button>
                    </div>
                <?php endwhile; ?>
            <?php endif; ?>
        </div> <!-- closing tag for div with class 'row' -->
    </div>
</section>

<?php get_footer(); ?>
